package org.zerock.myapp.domain;

import lombok.Value;

@Value
public class AlarmVO {
	private Integer alarmNo;
	private String content;
}
