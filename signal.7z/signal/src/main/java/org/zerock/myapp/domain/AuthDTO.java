package org.zerock.myapp.domain;

import lombok.Data;

@Data
public class AuthDTO {
	private String userId;
	private String auth;

}
