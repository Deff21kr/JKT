package org.zerock.myapp.domain;

import lombok.Value;

@Value
public class EvaluaateUserVO {
	private Integer evalNo;
	private Integer score;
}
