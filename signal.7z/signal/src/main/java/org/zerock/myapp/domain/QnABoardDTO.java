package org.zerock.myapp.domain;


import lombok.Data;

@Data			
public class QnABoardDTO {
	private Integer postno;
	private String nickname;
	private String title;
	private String content;
	
} // end class
